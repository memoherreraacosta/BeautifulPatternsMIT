
for i in range(1, 11):#imprime uno menos
    print(i);
