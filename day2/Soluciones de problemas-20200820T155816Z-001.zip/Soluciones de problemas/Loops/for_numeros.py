#For con números
#Objetivo: aprender cómo funciona el for

inicio=int(input('Número inicial: '))
fin=int(input('Número final: '))
for i in range (inicio,fin+1):
    print(i)

