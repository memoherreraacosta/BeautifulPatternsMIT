#While con contador
contador = 1;

while (contador <= 10): #hay otra forma de hacerlo "while contador <11"
    print (contador);
    contador += 1; #es lo mismo que si pusieras contador = contador + 1
